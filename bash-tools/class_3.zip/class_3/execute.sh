#!/bin/bash

# Execute script_1.py
python script_1.py      &

# Execute script_2.py
python script_2.py