# Read the first number
with open('number1.txt', 'r') as file:
    number1 = int(file.readline())

# Read the second number
with open('number2.txt', 'r') as file:
    number2 = int(file.readline())

# Compare the numbers
if number1 > number2:
    result = f"1st number {number1} is bigger than 2nd {number2}."
elif number1 < number2:
    result = f"2nd number {number2} is bigger than 1st {number1}."
else:
    result = f"Both numbers {number1}, {number2} are equal."

print(result)
