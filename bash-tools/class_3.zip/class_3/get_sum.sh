#!/bin/bash

p=`cat`

sum=0

for i in $p
do
	sum=$((sum + $i))
done

echo $sum