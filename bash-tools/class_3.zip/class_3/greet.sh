#!/bin/bash

function greet() {
    echo "Hello, $1! And $2 too!"
}

# Call the function
greet "$1" "$2"