import random
import time

def create_document(filename):
    with open(filename, 'w') as file:
        file.write(str(random.randint(1, 100)))

# Create the first document
create_document("number1.txt")
print("Created number1.txt")

# Wait for 20 sec
time.sleep(20)

# Create the second document
create_document("number2.txt")
print("Created number2.txt")
