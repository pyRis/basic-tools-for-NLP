#!/bin/bash

count=0

# Iterate through all files in the current directory
for file in *; do
    # Check if the file is a .sh file
    if [[ -f $file && $file == *.sh ]]; then
        ((count++))
    fi
done

echo "Number of .sh files: $count"